#include <stdio.h>

#include "b.h"
#include "c.h"
#include "d.h"
#include <string.h>

int b(void){
    return b.c;
}
