#!/bin/sh

#cat "$1" | while read -r line
#do
#	echo `echo $line | tr '0-4' '<'| tr '6-9' '>'`
#done 

tr '0-4' '<'| tr '6-9' '>'
